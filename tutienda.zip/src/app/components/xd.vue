<template>
    <h1>componente xd</h1>
</template>