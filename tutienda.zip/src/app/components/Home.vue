<template>
    <div>
        <navegador></navegador>
        <cuerpo></cuerpo>
    </div>
</template>
<script>
import navegador from '../components/Navegador.vue'
import cuerpo from '../components/Cuerpo.vue'
export default {
    components:{
        navegador,
        cuerpo
    }
    
}
</script>

 