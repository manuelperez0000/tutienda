import Vue from 'vue';
import App from './components/Login.vue';
 
new Vue({
  render: h => h(App)
}).$mount('#app');